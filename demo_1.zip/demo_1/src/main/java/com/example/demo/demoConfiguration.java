package com.example.demo;

public class demoConfiguration {
 
    
    private int maximum;  
    private int minimum;  

    public int getMaximum()   
    {  
    return maximum;  
    }  
    public int getMinimum()   
    {  
    return minimum;  
    }  

    public demoConfiguration(int maximum, int minimum)   
    {  
        super();  
        this.maximum = maximum;  
        this.minimum = minimum;  
    }  
}